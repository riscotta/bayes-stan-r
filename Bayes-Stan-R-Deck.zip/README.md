# Deck — Quantas partidas até 15 vitórias?

Exemplo independente de inferência bayesiana em R e Stan. O script simula sessões para quatro decks, ajusta um modelo binomial negativo com prior Beta e compara a amostragem Stan com a posterior conjugada. Todos os dados são gerados pelo script.

Por sessão, o modelo conta derrotas antes de atingir a meta de vitórias. Para um deck com probabilidade de vitória `p`, a esperança de partidas até `r` vitórias é `r/p`. Com prior `Beta(a0, b0)`, a posterior analítica do deck tem parâmetros `a0 + r × número de sessões` e `b0 + total de derrotas`.

## Instalação

Instale R e as ferramentas de compilação para seu sistema. No Windows, use a versão do Rtools correspondente ao seu R. Consulte o [guia do CmdStanR](https://mc-stan.org/cmdstanr/articles/cmdstanr.html).

Em uma sessão R:

```r
install.packages("posterior", repos = "https://cloud.r-project.org")
install.packages("cmdstanr", repos = c(
  "https://stan-dev.r-universe.dev",
  "https://cloud.r-project.org"
))
cmdstanr::check_cmdstan_toolchain()
cmdstanr::install_cmdstan(version = "2.40.0", cores = 2)
```

## Execução

Abra o terminal na pasta extraída e execute:

```bash
Rscript --vanilla scripts/deck_15wins/deck_15wins_negbin_beta_cmdstanr.R
```

O padrão usa quatro cadeias e a semente 20260211. A saída no console inclui divergências, saturações de treedepth, E-BFMI por cadeia, R-hat, ESS, comparação com a posterior analítica e checagens preditivas. Para cada deck, o parâmetro p é a probabilidade de vitória por partida no cenário simulado. A probabilidade de ser o melhor deck é calculada comparando p entre os decks a cada draw posterior. A interpretação fica restrita ao exercício sintético.

Para modificar a meta, use `--r=20`. Para amostrar somente a prior, use `--prior_only=1`. O script compara essa amostragem com a Beta especificada na entrada.

## Proveniência e licença

Derivado do [exemplo Deck do Bayes-Stan-R](https://github.com/riscotta/bayes-stan-r/tree/6cb8177b36b8f2fdaa48667fcc2c5c2c01b4078e/scripts/deck_15wins). A licença MIT acompanha o pacote. R, CmdStan e os pacotes R são instalados separadamente.

## Verificação do pacote

Testado em Linux com R 4.5.1, cmdstanr 0.9.0, posterior 1.8.1 e CmdStan 2.40.0.

- Na configuração padrão, as quatro cadeias concluíram 4.000 amostras pós-aquecimento. Foram observadas zero divergências, zero saturações de treedepth, R-hat máximo de 1,0033 e diferença absoluta máxima de 0,00059 entre as médias Stan e analíticas de p.
- Com `--prior_only=1 --chains=1 --iter_warmup=300 --iter_sampling=600`, o script concluiu a execução e usou a média analítica de 0,5 da Beta(2, 2) como referência para os quatro decks. Essa execução verificou o funcionamento do modo a priori com uma cadeia.
